import gymnasium as gym
import numpy as np
import random
import torch
import torch.nn as nn
import torch.optim as optim
from collections import deque
import matplotlib.pyplot as plt
from torch.utils.tensorboard import SummaryWriter

# Initialize TensorBoard writer
writer = SummaryWriter(log_dir="runs/Q2")

seed = 42
np.random.seed(seed)
random.seed(seed)
torch.manual_seed(seed)
torch.cuda.manual_seed_all(seed)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

env = gym.make('CartPole-v1')

class DQN(nn.Module):
    def __init__(self, input_size, output_size, hidden_layers):
        super(DQN, self).__init__()
        layers = [nn.Linear(input_size, 24), nn.ReLU()]
        for _ in range(hidden_layers):
            layers.extend([nn.Linear(24, 24), nn.ReLU()])
        layers.append(nn.Linear(24, output_size))
        self.network = nn.Sequential(*layers)

    def forward(self, x):
        return self.network(x)


def sample_batch(batch_size, experience_replay):
    return random.sample(experience_replay, batch_size)

def sample_action(state, model, epsilon):
    if np.random.rand() <= epsilon:
        return env.action_space.sample()
    with torch.no_grad():
        state = state.to(device, dtype=torch.float32)
        return model(state).max(1)[1].view(1, 1).item()

def test_agent(model):
    epsilon = 0
    with torch.no_grad():
        rewards = []
        for episode in range(100):
            state, _ = env.reset(seed=episode)
            state = torch.tensor(state, device=device, dtype=torch.float32).unsqueeze(0)
            total_reward = 0
            done = False
            truncated = False
            while not (done or truncated):
                action = sample_action(state, model, epsilon)
                next_state, reward, done, truncated, _ = env.step(action)
                next_state = torch.tensor(next_state, device=device, dtype=torch.float32).unsqueeze(0)
                reward = torch.tensor(reward, device=device, dtype=torch.float32).unsqueeze(0)
                total_reward += reward.item()
                state = next_state
            rewards.append(total_reward)
    return np.mean(rewards)


# Define hyperparameters grid
batch_sizes = [32, 256, 1024]
gammas = [0.95, 0.99]
learning_rates = [0.001, 0.0005]
epsilon_decays = [0.995, 0.99]


# Grid search function
def grid_search():
    hyperparam_combinations = [(bs, g, lr, ed) for bs in batch_sizes for g in gammas for lr in learning_rates for ed in epsilon_decays]

    for batch_size, gamma, lr, epsilon_decay in hyperparam_combinations:
        hyperparams_str = f"BS_{batch_size}_G_{gamma}_LR_{lr}_ED_{epsilon_decay}"
        # Initialize models for each combination
        # q_value_model = DQN(env.observation_space.shape[0], env.action_space.n, 3).to(device)
        # target_model = DQN(env.observation_space.shape[0], env.action_space.n, 3).to(device)
        q_value_model = DQN(env.observation_space.shape[0], env.action_space.n, 5).to(device)
        target_model = DQN(env.observation_space.shape[0], env.action_space.n, 5).to(device)
        target_model.load_state_dict(q_value_model.state_dict())
        target_model.eval()

        #torch.compile(q_value_model, mode="reduce-overhead")
        #torch.compile(target_model, mode="reduce-overhead")

        print(
            f"Training with batch_size={batch_size}, gamma={gamma}, lr={lr}, epsilon_decay={epsilon_decay}")

        # Train the agent with the current set of hyperparameters
        train_agent(q_value_model, target_model, batch_size=batch_size, gamma=gamma, lr=lr,
                    epsilon_decay=epsilon_decay, hyperparams_str=hyperparams_str)
def train_agent(q_value_model, target_model, episodes=1500, batch_size=1024, gamma=0.99, epsilon=1.0,
                epsilon_decay=0.995, epsilon_min=0.01, lr=0.001, update_target_every=5, hyperparams_str=""):
    experience_replay = deque(maxlen=300000)
    optimizer = optim.Adam(q_value_model.parameters(), lr)
    criterion = nn.MSELoss()
    for episode in range(episodes):
        state, _ = env.reset(seed=episode)
        state = torch.tensor(state, device=device, dtype=torch.float32).unsqueeze(0)
        total_reward = 0
        done = False
        truncated = False
        while not (done or truncated):
            action = sample_action(state, q_value_model, epsilon)
            next_state, reward, done, truncated, _ = env.step(action)
            next_state = torch.tensor(next_state, device=device, dtype=torch.float32).unsqueeze(0)
            reward = torch.tensor(reward, device=device, dtype=torch.float32).unsqueeze(0)
            experience_replay.append((state, action, reward, next_state, done))
            total_reward += reward.item()
            state = next_state

            if len(experience_replay) > batch_size:
                minibatch = sample_batch(batch_size, experience_replay)
                batch_state, batch_action, batch_reward, batch_next_state, batch_done = zip(*minibatch)
                batch_state = torch.cat(batch_state)
                batch_action = torch.tensor(batch_action, device=device).unsqueeze(1)
                batch_reward = torch.cat(batch_reward)
                batch_next_state = torch.cat(batch_next_state)
                non_final_mask = torch.tensor(tuple(map(lambda s: s is not True, batch_done)), device=device,
                                              dtype=torch.bool)
                current_q_values = q_value_model(batch_state).gather(1, batch_action)
                next_q_values = torch.zeros(batch_size, device=device)
                with torch.no_grad():
                    next_q_values[non_final_mask] = target_model(batch_next_state).max(1)[0].detach()[non_final_mask]
                expected_q_values = (next_q_values * gamma) + batch_reward
                loss = criterion(current_q_values, expected_q_values.unsqueeze(1))
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()

                # TensorBoard logging for loss and total reward
                writer.add_scalar(f'{hyperparams_str}/Loss', loss.item(), episode)
                writer.add_scalar(f'{hyperparams_str}/Total Reward', total_reward, episode)

        epsilon = max(epsilon_min, epsilon_decay * epsilon)
        if episode % update_target_every == 0:
            target_model.load_state_dict(q_value_model.state_dict())
        if episode % 100 == 0:
            q_value_model.eval()
            test_reward = test_agent(q_value_model)
            q_value_model.train()
            # Log average test reward to TensorBoard
            writer.add_scalar(f'{hyperparams_str}/Average Test Reward', test_reward, episode)
            print(f"Episode: {episode}, Reward: {test_reward}, Epsilon: {epsilon}")
            if test_reward > 475:
                print(f"Solved in {episode} episodes!")
                break
        # Closing the writer after training
    writer.close()

# Assuming necessary imports are done and DQN class, along with other functions, are defined above
grid_search()