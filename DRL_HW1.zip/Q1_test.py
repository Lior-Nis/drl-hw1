import gymnasium as gym
import numpy as np
import random
from torch.utils.tensorboard import SummaryWriter
import matplotlib.pyplot as plt

# Initialize TensorBoard writer
writer = SummaryWriter(log_dir="runs/Q1_test")

np.random.seed(42)
random.seed(42)
env = gym.make("FrozenLake-v1")

# Hyperparameter ranges
learning_rates = [0.4]
discount_factors = [0.95]
decay_rates = [0.01]

total_episodes = 5000

best_steps = np.inf
best_hyperparams = {}
best_Q_table = None

for learning_rate in learning_rates:
    for discount_factor in discount_factors:
        for decay_rate in decay_rates:
            # Create a unique name for each experiment based on hyperparameters
            experiment_name = f"LR_{learning_rate}_DF_{discount_factor}_DR_{decay_rate}"
            Q_table = np.zeros((env.observation_space.n, env.action_space.n))
            epsilon = 1.0
            steps = []

            for episode in range(total_episodes):
                state = env.reset()[0]
                step = 0
                terminated = False
                truncated = False

                while not (terminated or truncated):
                    step += 1
                    exploitation = np.random.uniform(0, 1)
                    if exploitation > epsilon:
                        action = np.argmax(Q_table[state, :])
                    else:
                        action = env.action_space.sample()

                    observation, reward, terminated, truncated, info = env.step(action)
                    Q_table[state, action] = (1 - learning_rate) * Q_table[state, action] + learning_rate * (reward + discount_factor * np.max(Q_table[observation, :]))
                    state = observation

                epsilon *= max((1 - decay_rate), 0.01)
                steps.append(step if reward == 1 else 100)

                # Log average steps for this episode with hyperparameters in the name
                writer.add_scalar(f"{experiment_name}/Reward", reward, episode)

            avg_steps = np.mean(steps)

            if avg_steps < best_steps:
                best_steps = avg_steps
                best_hyperparams = {'learning_rate': learning_rate, 'discount_factor': discount_factor, 'decay_rate': decay_rate}
                best_Q_table = Q_table.copy()

# Closing the writer
writer.close()
fig, ax = plt.subplots(figsize=(5,13))  # Adjust the size as needed
cax = ax.matshow(best_Q_table, cmap='viridis')  # Choose a colormap that suits your preference
plt.colorbar(cax)
for i in range(best_Q_table.shape[0]):
    for j in range(best_Q_table.shape[1]):
        ax.text(j, i, f'{best_Q_table[i, j]:.2f}', ha='center', va='center', color='w')
plt.show()
print("Best Hyperparameters:", best_hyperparams)
print("Best steps:", best_steps)

