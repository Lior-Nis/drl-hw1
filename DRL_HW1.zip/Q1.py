import gymnasium as gym
import numpy as np
import random
from torch.utils.tensorboard import SummaryWriter

# Initialize TensorBoard writer
writer = SummaryWriter(log_dir="runs/Q1")

np.random.seed(42)
random.seed(42)
env = gym.make("FrozenLake-v1")

# Hyperparameter ranges
learning_rates = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.8]
discount_factors = [0.9, 0.95, 0.99, 0.999]
decay_rates = [0.0001, 0.001, 0.01, 0.05, 0.1]

total_episodes = 5000

best_steps = np.inf
best_hyperparams = {}
best_Q_table = None

for learning_rate in learning_rates:
    for discount_factor in discount_factors:
        for decay_rate in decay_rates:
            # Create a unique name for each experiment based on hyperparameters
            experiment_name = f"LR_{learning_rate}_DF_{discount_factor}_DR_{decay_rate}"
            Q_table = np.zeros((env.observation_space.n, env.action_space.n))
            epsilon = 1.0
            steps = []

            for episode in range(total_episodes):
                state = env.reset()[0]
                step = 0
                terminated = False
                truncated = False

                while not (terminated or truncated):
                    step += 1
                    exploitation = np.random.uniform(0, 1)
                    if exploitation > epsilon:
                        action = np.argmax(Q_table[state, :])
                    else:
                        action = env.action_space.sample()

                    observation, reward, terminated, truncated, info = env.step(action)
                    Q_table[state, action] = (1 - learning_rate) * Q_table[state, action] + learning_rate * (reward + discount_factor * np.max(Q_table[observation, :]))
                    state = observation

                epsilon *= max((1 - decay_rate), 0.01)
                steps.append(step if reward == 1 else 100)

                # Log average steps for this episode with hyperparameters in the name
                writer.add_scalar(f"{experiment_name}/Average_Steps", steps[-1], episode)

            avg_steps = np.mean(steps)

            if avg_steps < best_steps:
                best_steps = avg_steps
                best_hyperparams = {'learning_rate': learning_rate, 'discount_factor': discount_factor, 'decay_rate': decay_rate}
                best_Q_table = Q_table.copy()

# Closing the writer
writer.close()

print("Best Hyperparameters:", best_hyperparams)
print("Best steps:", best_steps)

