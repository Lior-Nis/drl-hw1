from collections import deque
import gymnasium as gym
import matplotlib.pyplot as plt
import numpy as np
import random
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.tensorboard import SummaryWriter

seed = 42
np.random.seed(seed)
random.seed(seed)
torch.cuda.manual_seed_all(seed)

# Check for GPU
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Initialize the environment
env = gym.make('CartPole-v1')


# Neural Network for DQN
class DQN(nn.Module):
    def __init__(self, input_size, output_size, hidden_layers):
        super(DQN, self).__init__()
        layers = [nn.Linear(input_size, 24), nn.ReLU()]
        for _ in range(hidden_layers):
            layers.extend([nn.Linear(24, 24), nn.ReLU()])
        layers.append(nn.Linear(24, output_size))
        self.network = nn.Sequential(*layers)

    def forward(self, x):
        return self.network(x)


# Create two models
q_value_A = DQN(env.observation_space.shape[0], env.action_space.n, 5).to(device)
q_value_B = DQN(env.observation_space.shape[0], env.action_space.n, 5).to(device)

# Sample batch function
def sample_batch(batch_size, experience_replay):
    return random.sample(experience_replay, batch_size)


# Sample action function
def sample_action_double(state, modelA, modelB, epsilon):
    if np.random.rand() <= epsilon:
        return env.action_space.sample()
    with torch.no_grad():
        state = state.to(device, dtype=torch.float32)
        Qs_A = modelA(state)
        Qs_B = modelB(state)
        Qs = Qs_A + Qs_B
        return Qs.max(1)[1].view(1, 1).item()


def test_agent_double(modelA, modelB):
    epsilon = 0
    with torch.no_grad():
        rewards = []
        for episode in range(100):
            state, _ = env.reset(seed=episode)
            state = torch.tensor(state, device=device, dtype=torch.float32).unsqueeze(0)
            total_reward = 0
            done = False
            truncated = False
            while not (done or truncated):
                action = sample_action_double(state, modelA, modelB, epsilon)
                next_state, reward, done, truncated, _ = env.step(action)

                next_state = torch.tensor(next_state, device=device, dtype=torch.float32).unsqueeze(0)
                reward = torch.tensor(reward, device=device, dtype=torch.float32).unsqueeze(0)

                total_reward += reward.item()
                state = next_state
            rewards.append(total_reward)
    return np.mean(rewards)


# Train agent function
def train_DDQN(modelA, modelB, episodes=3000, batch_size=1024, gamma=0.95, epsilon=1.0,
               epsilon_decay=0.995, epsilon_min=0.01, lr=0.001):
    # Initialize TensorBoard writer for this training session
    writer = SummaryWriter(log_dir=f"board/DDQN_BS_{batch_size}_LR_{lr}_GAMMA_{gamma}")

    experience_replay = deque(maxlen=300000)
    optimizerA = optim.Adam(modelA.parameters(), lr)
    optimizerB = optim.Adam(modelB.parameters(), lr)
    criterion = nn.MSELoss()
    losses = []
    rewards = []
    for episode in range(episodes):
        state, _ = env.reset(seed=episode)
        state = torch.tensor(state, device=device, dtype=torch.float32).unsqueeze(0)
        total_reward = 0
        done = False
        truncated = False
        while not (done or truncated):

            action = sample_action_double(state, modelA, modelB, epsilon)
            next_state, reward, done, truncated, _ = env.step(action)

            next_state = torch.tensor(next_state, device=device, dtype=torch.float32).unsqueeze(0)
            reward = torch.tensor(reward, device=device, dtype=torch.float32).unsqueeze(0)

            experience_replay.append((state, action, reward, next_state, done))
            total_reward += reward.item()
            state = next_state

            if len(experience_replay) > batch_size:
                minibatch = sample_batch(batch_size, experience_replay)
                batch_state, batch_action, batch_reward, batch_next_state, batch_done = zip(*minibatch)
                batch_state = torch.cat(batch_state)
                batch_action = torch.tensor(batch_action, device=device).unsqueeze(1)
                batch_reward = torch.cat(batch_reward)
                batch_next_state = torch.cat(batch_next_state)
                non_final_mask = torch.tensor(tuple(map(lambda s: s is not True, batch_done)), device=device,
                                              dtype=torch.bool)

                if np.random.rand() <= 0.5:
                    q_value_model = modelA
                    target_model = modelB
                    optimizer = optimizerA

                else:
                    q_value_model = modelB
                    target_model = modelA
                    optimizer = optimizerB

                current_q_values = q_value_model(batch_state).gather(1, batch_action)
                next_q_values = torch.zeros(batch_size, device=device)
                with torch.no_grad():
                    next_q_values[non_final_mask] = target_model(batch_next_state).max(1)[0].detach()[non_final_mask]
                expected_q_values = (next_q_values * gamma) + batch_reward
                loss = criterion(current_q_values, expected_q_values.unsqueeze(1))
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()
                losses.append(loss.item())

        epsilon = max(epsilon_min, epsilon_decay * epsilon)

        # Log training metrics to TensorBoard
        writer.add_scalar('Training/Total Reward', total_reward, episode)
        if len(losses) > 0:  # Ensure there was at least one training step
            writer.add_scalar('Training/Loss', losses[-1], episode)

        if episode % 100 == 0:
            test_reward = test_agent_double(modelA, modelB)
            writer.add_scalar('Test/Average Reward', test_reward, episode)
            print(f"Episode: {episode}, Reward: {test_reward}, Epsilon: {epsilon}")
            if test_reward >= 475:
                print(f"Environment solved in {episode} episodes!")
                break

        # Close the TensorBoard writer
    writer.close()

    return losses, rewards


# Train the agent
losses, rewards = train_DDQN(q_value_A, q_value_B)
